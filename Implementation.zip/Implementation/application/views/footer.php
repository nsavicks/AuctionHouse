<?php

    echo '
    <footer>
        <p>&copy; 2019 AuctionHouse</p>
    </footer>
    </body>

    </html>
    ';

?>